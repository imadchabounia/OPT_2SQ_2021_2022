from django.apps import AppConfig


class PathfinderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pathfinder'
