import time
import random
import math

items = []
capacity = 0

class SolutionCLass:

    def __init__(self):
        self.solution_vector = list()
        self.solution_vector_initial = list()
        self.solution_fitness_initial = list()
        self.solution_fitness = list()
        self.solution_time = list()
        self.executions = list()

    def addSolutionVector(self, s_v):
        self.solution_vector.append(s_v)

    def addSolutionFitness(self, s_f):
        self.solution_fitness.append(s_f)

    def addSolutionTime(self, s_t):
        self.solution_time.append(s_t)

    def addExecution(self, exec):
        self.executions.append(exec)

    def addSolutionVectorInitial(self, solution):
        self.solution_vector_initial.append(solution)

    def addSolutionFitnessInitial(self, fitness):
        self.solution_fitness_initial.append(fitness)


def tri_a(element):
    return element[0]/element[1]

def heuristique(k):

    items_copy = items.copy()
    items_copy.sort(reverse=True, key=k)
    result = 0
    n = len(items_copy)
    i = int(0)
    solution = [0]*n #les valeurs de x
    W = capacity

    while i < n:
        x = 0
        while W-items_copy[i][1] > 0:
            result += items_copy[i][0]
            W -= items_copy[i][1]
            x += 1

        solution[items_copy[i][2]] = x
        i += 1

    return solution

def genererVoisins(S, borne_sup_perturbation):
    voisins = list()
    """
    for i in range(0, len(S)):

        tmp_S = S.copy()
        for k in range(1, borne_sup_perturbation):
            tmp_S[i] += 1
            tmp_to_append = tmp_S.copy()
            voisins.append(tmp_to_append)
        tmp_S = S.copy()
        for k in range(1, borne_sup_perturbation):
            if tmp_S[i] >= 1:
                tmp_S[i] -= 1
                tmp_to_append = tmp_S.copy()
                voisins.append(tmp_to_append)
    """

    for i in range(0, len(S)):
        for k in range(1, borne_sup_perturbation+1):
            tmp_S = S.copy()
            tmp_S[i] = tmp_S[i] + k
            voisins.append(tmp_S)
        for k in range(1, borne_sup_perturbation+1):
            tmp_S = S.copy()
            if tmp_S[i] >= k:
                tmp_S[i] -= k
                voisins.append(tmp_S)

    """
    for k in range(0, 100000):
        random_solution = [random.randint(0, borne_sup_perturbation) for i in range(0, len(S))]
        if(fitness(random_solution) <= 0):
            continue
        voisins.append(random_solution)
    """
    return voisins

def fitness(S):
    profit = 0
    C = capacity
    for i in range(0, len(S)):
        profit += (items[i][0]*S[i])
        C -= (items[i][1]*S[i])
        if C < 0:
            return -1
    return profit

def recuit_simule(borne_inf_temperature, R, T, S0, borne_sup_perturbation):

    S_etoile = S0.copy()
    S = S0.copy()
    #R = 100
    #borne_inf_temperature = 1
    #T = 10230
    alpha = .9
    stop = False

    while not stop:

        S_etoile_ancienne = S_etoile.copy()
        voisins = genererVoisins(S,borne_sup_perturbation)
        #selectionner le meilleurs des voisins
        iter = R

        while iter > 0:

            i = random.randint(0, len(voisins)-1)
            S_prime = voisins[i]
            if(fitness(S_prime) >=  fitness(S)):
                S = S_prime
            else:
                r = random.random()
                Delta_F = fitness(S)-fitness(S_prime)
                if r < math.exp(-(Delta_F/T)):
                    S = S_prime

            if fitness(S) > fitness(S_etoile):
                S_etoile = S

            iter -= 1

        T = alpha*T
        if T <= borne_inf_temperature:
            stop = True

    return S_etoile


def worker_recuit_simule(file, borne_inf_temperature, R, T, borne_sup_perturbation):

    global items
    global capacity
    # solutions = SolutionCLass()

    solutions = list()

    # file = open("testcases.txt", 'r')
    benefices = []
    for line in file:
        values = line.split()
        if len(values) == 0:
            continue
        else:
            if values[0] == b'$1':
                capacity = int(values[-1])
            elif values[0] == b'$2':
                benefices = values[1:]
            elif values[0] == b'$3':
                values = values[1:]
                for i in range(0, len(benefices)):
                    items.append([int(benefices[i]), int(values[i]), i])
                S0 = [0]*len(items)
                time_start = time.perf_counter()
                S_etoile = recuit_simule(borne_inf_temperature, R, T, S0, borne_sup_perturbation)
                time_end = time.perf_counter()
                time_spent = time_end - time_start

                # solutions.addSolutionVector(S_etoile)
                # solutions.addSolutionTime(time_spent)
                # solutions.addSolutionFitness(fitness(S_etoile))
                # solutions.addSolutionVectorInitial(S0)
                # solutions.addSolutionFitnessInitial(fitness(S0))
                solution = {'vector': S_etoile,
                            'fitness': fitness(S_etoile),
                            'time': time_spent,
                            'init_vector': S0,
                            'init_fitness': fitness(S0)}

                solutions.append(solution)

                capacity = 0
                items = []

    return solutions

# print(worker_recuit_simule(1, 1000, 1023000, 6).solution_vector_initial[0])
