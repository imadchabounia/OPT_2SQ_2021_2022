infinity = 10000000000000

import time

class SolutionCLass:

    def __init__(self):
        self.solution_vector = list()
        self.solution_vector_initial = list()
        self.solution_fitness_initial = list()
        self.solution_fitness = list()
        self.solution_time = list()
        self.executions = list()

    def addSolutionVector(self, s_v):
        self.solution_vector.append(s_v)

    def addSolutionFitness(self, s_f):
        self.solution_fitness.append(s_f)

    def addSolutionTime(self, s_t):
        self.solution_time.append(s_t)

    def addExecution(self, exec):
        self.executions.append(exec)

    def addSolutionVectorInitial(self, solution):
        self.solution_vector_initial.append(solution)

    def addSolutionFitnessInitial(self, fitness):
        self.solution_fitness_initial.append(fitness)

def tri_a(element):
    return element[0]/element[1]

def changeProfit(items, current_capacity, current_profit, solution, i, x):

    init_x = solution[i]
    diff = init_x-x
    ni = -1
    nxi = 0
    current_capacity += items[i][1]*diff
    current_profit -= items[i][0]*diff
    best_profit = 0
    j = i+1

    while j < len(items):
        if(current_capacity >= items[j][1]):
            xj = int(current_capacity/items[j][1])
            if(best_profit < xj*items[j][0]):
                best_profit = xj*items[j][0]
                ni = j
                nxi = xj
        j += 1
    return best_profit+current_profit, ni, nxi


def heuristique2(capacity, items, k):

    #Pahse 1
    items.sort(reverse=True, key=k)
    result = 0
    n = len(items)
    i = int(0)
    solution_vector = [0]*n #les valeurs de x
    W = capacity
    m = n #est un paramètre à choisir

    while i < m:
        x = 0
        while W-items[i][1] > 0:
            result += items[i][0]
            W -= items[i][1]
            x += 1
        solution_vector[items[i][2]] = x
        i += 1

    return solution_vector, result

def worker_heuristique(file):
    # file = open("testcases.txt", 'r')
    benefices = []
    # solutions = SolutionCLass()

    solutions = []

    for line in file:
        values = line.split()
        if len(values) == 0:
            continue
        else:
            if values[0] == b'$1':
                W = int(values[-1])
            elif values[0] == b'$2':
                benefices = values[1:]
            elif values[0] == b'$3':
                items = []
                values = values[1:]
                for i in range(0, len(benefices)):
                    items.append([int(benefices[i]), int(values[i]), i])

                time_start = time.perf_counter()
                S_etoile, fitness = heuristique2(W, items, tri_a)
                time_end = time.perf_counter()
                time_spent = time_end - time_start
                # solutions.addSolutionVector(S_etoile)
                # solutions.addSolutionTime(time_spent)
                # solutions.addSolutionFitness(fitness)
                # solutions.addSolutionVectorInitial([0]*len(items))
                # solutions.addSolutionFitnessInitial(0)

                solution = {'vector': S_etoile,
                            'fitness': fitness,
                            'time': time_spent,
                            'init_vector': [0] * len(items),
                            'init_fitness': 0}

                solutions.append(solution)

    return solutions
