from django import forms


class PathfinderForm(forms.Form):
    file = forms.FileField(label="Upload file here")
    pop_initial = forms.IntegerField(label='Taille de la population initiale')
    max_iter_initial = forms.IntegerField(label='MAX Iterations Initial')
    max_iter = forms.IntegerField(label='MAX Iterations')
    bound = forms.IntegerField(label='Borne sup')
    u_max = forms.IntegerField(label='U MAX')
    r_max = forms.IntegerField(label='R MAX')

    hybrid = forms.BooleanField(required=False)

    pop_initial.widget.attrs.update({'placeholder': 'population initial'})


class BandHForm(forms.Form):
    file = forms.FileField(label="Upload file here")


class AGForm(forms.Form):
    file = forms.FileField(label="Upload file here")

    pop_initial = forms.IntegerField(label='Taille de la population initiale')
    taux_croisement = forms.FloatField(label='Taux de croisement')
    taux_mutation = forms.FloatField(label='Taux de mutation')
    k = forms.IntegerField(label='Nombre d’individus sélectionnés (durant la phase de sélection)')
    max_iter = forms.IntegerField(label='Nombre maximum d\'itérations')
    # stuck_itrer = forms.IntegerField(label='Nombre d’itérations maximum de stagnation')


class RSForm(forms.Form):
    file = forms.FileField(label="Upload file here")
    borne_inf_temperature = forms.IntegerField(label='Borne inf de la température')
    r = forms.IntegerField(label='Nombre d’itération pour chaque valeur de la température')
    t_init = forms.IntegerField(label='Valeur initial de la température')
    borne_sup_pert = forms.IntegerField(label='Borne sup de la perturbation')
