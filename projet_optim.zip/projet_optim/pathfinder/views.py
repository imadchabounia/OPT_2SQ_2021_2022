from django.shortcuts import render
from .forms import PathfinderForm, RSForm, AGForm, BandHForm
from django.conf import settings

from .pathfinder_hybrid_django import PFAParameters, worker
from .branch_and_bound import worker_branch_and_bound
from .heuristique import worker_heuristique
from .ag import worker_ag
from .recuit_simule import worker_recuit_simule
from matplotlib import pyplot as plt


def home(request):
    return render(request, 'pathfinder/home.html', {'home_active': 'active'})


def save_plot(x, y, i):
    plt.title("Benchmark")
    plt.ylabel("Evaluations")
    plt.xlabel("Ittération")

    plt.plot(x, y)
    # plt.show()
    plt.savefig(settings.MEDIA_ROOT+'/'+f'{i}.png')
    plt.clf()


def pfa(request):
    data = dict()
    if request.method == 'POST':
        form = PathfinderForm(request.POST, request.FILES)

        if form.is_valid():
            file = request.FILES['file']

            posted_data = form.cleaned_data

            pop_initial = posted_data['pop_initial']
            max_iter_initial = posted_data['max_iter_initial']
            max_iter = posted_data['max_iter']
            bound = posted_data['bound']
            u_max = posted_data['u_max']
            r_max = posted_data['r_max']
            with_hybrid = posted_data['hybrid']
            p = PFAParameters(pop_initial, max_iter_initial, max_iter, bound, u_max, r_max)

            solutions = worker(file, p, withHybrid=with_hybrid)

            print(solutions)

            i = 0
            for s in solutions:
                save_plot(s['execution'].iterations, s['execution'].evaluations, i)
                solutions[i]['i'] = f'{i}.png'
                i += 1

            data['solutions'] = solutions

            data['result'] = True
    else:
        form = PathfinderForm()
        data['result'] = False

    return render(request, 'pathfinder/pfa.html', {'data': data, 'form': form, 'pfa_active': 'active'})


def branch_bound(request):
    data = dict()

    if request.method == 'POST':
        form = BandHForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['file']

            solutions = worker_branch_and_bound(file)

            print(solutions)
            data['solutions'] = solutions

            data['result'] = True

    else:
        form = BandHForm()
        data['result'] = False

    return render(request, 'pathfinder/bandh.html', {'data': data,
                                                     'form': form,
                                                     'b_active': 'active',
                                                     'method': 'Branch & Bound',
                                                     'color': 'green',
                                                     'icon': 'check circle'})


def heuristique(request):
    data = dict()
    if request.method == 'POST':
        form = BandHForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['file']

            solutions = worker_heuristique(file)

            print(solutions)

            data['solutions'] = solutions

            data['result'] = True

    else:
        form = BandHForm()
        data['result'] = False

    return render(request, 'pathfinder/bandh.html', {'form': form,
                                                     'data': data,
                                                     'heur_active': 'active',
                                                     'method': 'Heuristique',
                                                     'color': 'yellow',
                                                     'icon': 'bolt'})


def recuit_simule(request):
    data = dict()
    if request.method == 'POST':
        form = RSForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['file']

            borne_inf_temperature = form.cleaned_data['borne_inf_temperature']
            r = form.cleaned_data['r']
            t_init = form.cleaned_data['t_init']
            borne_sup_pert = form.cleaned_data['borne_sup_pert']

            solutions = worker_recuit_simule(file, borne_inf_temperature, r, t_init, borne_sup_pert)

            print(solutions)

            data['solutions'] = solutions

            data['result'] = True
    else:
        form = RSForm()
        data['result'] = False

    return render(request, 'pathfinder/rs.html', {'form': form,
                                                  'data': data,
                                                  'rs_active': 'active'})


def ag(request):
    data = dict()
    if request.method == 'POST':
        form = AGForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['file']

            pop_initial = form.cleaned_data['pop_initial']
            taux_croisement = form.cleaned_data['taux_croisement']
            taux_mutation = form.cleaned_data['taux_mutation']
            k = form.cleaned_data['k']
            max_iter = form.cleaned_data['max_iter']
            # stuck_itrer = form.cleaned_data['stuck_itrer']

            solutions = worker_ag(file, k, max_iter, pop_initial, taux_mutation, taux_croisement)

            print(solutions)

            data['solutions'] = solutions

            data['result'] = True
    else:
        form = AGForm()

        data['result'] = False

    return render(request, 'pathfinder/ag.html', {'form': form,
                                                  'data': data,
                                                  'ag_active': 'active'})
