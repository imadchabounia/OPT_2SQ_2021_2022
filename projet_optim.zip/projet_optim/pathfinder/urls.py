from django.urls import path, include
from . import views

app_name = "pathfinder"

urlpatterns = [
    path('',views.home, name='home'),
    path('pfa/', views.pfa, name="pfa"),
    path('branch_and_bound/', views.branch_bound, name="branch"),
    path('hueristique/', views.heuristique, name="heuristique"),
    path('rs/', views.recuit_simule, name="recuit_simule"),
    path('ag/', views.ag, name="ag"),
]
